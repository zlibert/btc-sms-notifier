require 'test_helper'

class IncomingtransactionsControllerTest < ActionDispatch::IntegrationTest
  setup do
    @incomingtransaction = incomingtransactions(:one)
  end

  test "should get index" do
    get incomingtransactions_url, as: :json
    assert_response :success
  end

  test "should create incomingtransaction" do
    assert_difference('Incomingtransaction.count') do
      post incomingtransactions_url, params: { incomingtransaction: {  } }, as: :json
    end

    assert_response 201
  end

  test "should show incomingtransaction" do
    get incomingtransaction_url(@incomingtransaction), as: :json
    assert_response :success
  end

  test "should update incomingtransaction" do
    patch incomingtransaction_url(@incomingtransaction), params: { incomingtransaction: {  } }, as: :json
    assert_response 200
  end

  test "should destroy incomingtransaction" do
    assert_difference('Incomingtransaction.count', -1) do
      delete incomingtransaction_url(@incomingtransaction), as: :json
    end

    assert_response 204
  end
end
