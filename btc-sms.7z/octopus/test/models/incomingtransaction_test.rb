require 'test_helper'

class IncomingtransactionTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
