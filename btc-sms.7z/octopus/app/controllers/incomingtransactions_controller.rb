### httpS isn't being used due errors. Serious usage should overlook this issue
### Other microservices/API calls should be made inside functions/methods to improve code
### Exchange rates should be implemented via own microservice with 2 more backup services in case
### the first one fails

class IncomingtransactionsController < ApplicationController
  before_action :set_incomingtransaction, only: [:show, :update, :destroy]

  # GET /incomingtransactions
  def index
    @incomingtransactions = Incomingtransaction.all

    render json: @incomingtransactions
  end

  # GET /incomingtransactions/1
  def show
    render json: @incomingtransaction
  end

  # POST /incomingtransactions
  def create
    
    outputs= incomingtransaction_params[:output]
    btcHash= incomingtransaction_params[:hash]
    #### Obtain account information by btcAddress
    puts "\n\n\tOCTOPUS : Solicitando informacion de  Transactions.btcHash  para: #{btcHash}"
    #uri = URI('http://localhost:3000/accounts/find')                         #datacontroller
    uri = URI('http://morning-anchorage-37892.herokuapp.com/transactions/find')   #datacontroller
    req = Net::HTTP::Post.new(uri, 'Content-Type' => 'application/json')
    req.body = {transaction: {btcHash: btcHash}}.to_json
    puts ("body:  " + req.body)
    res = Net::HTTP.start(uri.hostname, uri.port) do |http|
      http.request(req)
    end#do
    #puts ("#################### Respuesta ######################")
    #puts (res.body)
    #puts (res.code)
    #puts ("######################################################")
    if (res.code == '200')
      #puts ("Response: " + res.body)
      #puts ("Transaction already exists. Ignoring.")
      newTx = false
    else
      if (res.code =='404')
        newTx = true
        #puts ("Transaction is NEW ++++++++++++++++++++ Saving hash")
        ## SAVING TRANSACTION INTO TRANSACTION LOG ON DATACONTROLLER
        uri = URI('http://morning-anchorage-37892.herokuapp.com/transactions/')   #datacontroller
        req = Net::HTTP::Post.new(uri, 'Content-Type' => 'application/json')
        req.body = {transaction: {btcHash: btcHash}}.to_json
        puts ("Saving transaction into Log:  " + req.body)
        res = Net::HTTP.start(uri.hostname, uri.port) do |http|
          http.request(req)
        end#do
        if (res.code == '201') #saved successfully
          txLogId = res.body;
          puts ("Response 201. Tx saved. Datacontroller transaction ID: #{txLogId}")
        else
          puts ("Error Saving Transaction to Log")
        end#if
      end#if
    end#if
    if newTx
      outputs.each do |output|

        btcAddresses= output[:addresses]
        puts "\n==========================================================================================="
        btcAddresses.each do |btcAddress|
          puts "\n\n\tOCTOPUS : Solicitando informacion de  Account  para: #{btcAddress}"
          #uri = URI('http://localhost:3000/accounts/find')                         #datacontroller
          uri = URI('http://morning-anchorage-37892.herokuapp.com/accounts/find')   #datacontroller
          req = Net::HTTP::Post.new(uri, 'Content-Type' => 'application/json')
          req.body = {btcAddress: btcAddress}.to_json
          res = Net::HTTP.start(uri.hostname, uri.port) do |http|
            http.request(req)
          end#do

          ## Below should be a condition like: and res.hash is not in recentTxLog (already processed)
          if res.code == '200'    ## if the account exists (datacontroller returned the account's JSON)
            
            currency= 'VEF' # currency should be obtained from user profile (preferred fiat Currency for notifications)

            account= JSON.parse res.body          #save into hash
            puts "\tRespuesta (Account): #{res.body}"
            #### Obtain user information by user_id
            user_id= account["user_id"]
            puts "\n\tOCTOPUS : Solicitando informacion de  User para user_id: #{user_id}"      
            #uri = URI("http://localhost:3000/users/#{user_id}")                        #datacontroller
            uri = URI("http://morning-anchorage-37892.herokuapp.com/users/#{user_id}")  #datacontroller
            res= Net::HTTP.get(uri)
            user= JSON.parse res                  #save into hash
            puts "Respuesta (User): #{res}"

            #### Obtain notification_method by account_id
            account_id = account["id"]
            puts "\n\tOCTOPUS : Solicitando informacion de  NotificationMethod para account_id: #{account_id}"
            #uri = URI('http://localhost:3000/notification_methods/find')               #datacontroller
            uri = URI('http://morning-anchorage-37892.herokuapp.com/notification_methods/find')   #datacontroller
            req = Net::HTTP::Post.new(uri, 'Content-Type' => 'application/json')
            req.body = {account_id: account_id}.to_json
            res = Net::HTTP.start(uri.hostname, uri.port) do |http|
              http.request(req)
            end#do
            puts "\tRespuesta de Datacontroller (NotificationMethod): #{res.body}"
            notificationmethod= JSON.parse res.body    #save into hash
            #### Here we must also consider the possibility of multiple notification methods 
            #### for the same account   

            ### Consulting BTC/VEF Exchange rate (should be implemented for User.preferredFiat currency)
            uri = URI('http://api.bitcoinvenezuela.com/')        #morse
            req= Net::HTTP.get(uri)
            req= JSON.parse req
            exchRate= req["BTC"]["VEF"]
            #puts ("A P I\tExch Rate Bitcoin Venezuela: : : :  : #{exchRate}")

            ##### SENDING SMS
            uri = URI('http://frozen-dusk-49199.herokuapp.com/sendmessages')        #morse
            req= Net::HTTP::Post.new(uri, 'Content-Type' => 'application/json')
            
            way= notificationmethod["way"]
            countryCode= notificationmethod["countryCode"]
            contact= notificationmethod["phoneNumber"]
            
            userName= user["name1"]
            fiatAmount = ((output[:value].to_f / 100000000) * exchRate).round(2)   #must add Broker calculations
            message = "#{userName} has recibido #{fiatAmount}"
            req.body = {way: way, countryCode: countryCode, contact: contact, message: message}.to_json
            puts "\tSending message to Notification Method (#{message})"
            res = Net::HTTP.start(uri.hostname, uri.port) do |http|
              http.request(req)
            end#do
            puts "\tRespuesta (Morse) : #{res.body}"
         
            ## Updating saved hash with currency, fiat and btc amounts 
            #(should be change to use the id, not hash, using variable  txLogId )
            uri = URI('http://morning-anchorage-37892.herokuapp.com/transactions/update')   #datacontroller
            req = Net::HTTP::Post.new(uri, 'Content-Type' => 'application/json')
            req.body = {transaction: {btcHash: btcHash, btcAmount: output[:value], fiatAmount: fiatAmount, currency: currency}}.to_json
            #puts ("Updating transaction into Log")
            res = Net::HTTP.start(uri.hostname, uri.port) do |http|
              http.request(req)
            end#do
            #puts("=>=>=>=>=> Respuesta al hacer update: #{res.code} , #{res.body}")
            if (res.code == '200') #saved successfully
              txLogId = res.body;
              #puts ("Response 201. Tx updated")
            else
              puts ("Error Updating Transaction to Log")
            end#if

          else
            puts "\tAddress not found. Message from Datacontroller: #{res.body}"

          end#if
        end#each
      end#each
    else
      puts ("Transaction repeated. Ignroed by\tOCTOPUS");
    end#if newTx


    render json: {message: "Received" } , status: :ok
  end

  # PATCH/PUT /incomingtransactions/1
  def update
    if @incomingtransaction.update(incomingtransaction_params)
      render json: @incomingtransaction
    else
      render json: @incomingtransaction.errors, status: :unprocessable_entity
    end
  end

  # DELETE /incomingtransactions/1
  def destroy
    @incomingtransaction.destroy
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_incomingtransaction
      @incomingtransaction = Incomingtransaction.find(params[:id])
    end

    # Only allow a trusted parameter "white list" through.
  
    def incomingtransaction_params 
      params.require(:incomingtransaction).permit(:hash, :date, :doubleSpend,
        :output => [:value, :addresses => [] ]
      )
    end
end
