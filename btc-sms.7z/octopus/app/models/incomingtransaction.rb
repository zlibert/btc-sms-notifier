class Incomingtransaction < ApplicationRecord
end
