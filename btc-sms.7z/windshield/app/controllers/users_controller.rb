class UsersController < ApplicationController
  before_action :set_user, only: [:show, :edit, :update, :destroy]

  # GET /users
  # GET /users.json
  def index
    @users = User.all
  end

  # GET /users/1
  # GET /users/1.json
  def show
  end

  # GET /users/new
  def new
    # default view is currently running
    ## Validations
    ## User clicks submit
    ## Then call a JSON to octopus with validated data and it should handle the rest

    ## Is it ok to handle creation at new or should I just validate here and send the
    ## creation JSON to octopus   AT  CREATE  ACTION?

  end

  # GET /users/1/edit
  def edit
  end

  # POST /users
  # POST /users.json
  def create
    email = user_params[:email]
    login = user_params[:login]
    password = user_params[:password]
    userType = user_params[:userType]
    name1 = user_params[:name1]
    name2 = user_params[:name2]
    lastname1 = user_params[:lastname1]
    lastname2 = user_params[:lastname2]
    way = user_params[:way]
    countryCode = user_params[:countryCode]
    phoneNumber = user_params[:phoneNumber]
    btcAddress = user_params[:btcAddress]

    if email.length>4 and btcAddress.length>=25 and btcAddress.length<=34 and phoneNumber.length==10 and countryCode.length>1 and countryCode.length<5
      #uri = URI('http://still-brushlands-80314.herokuapp.com/users/new')
      puts "================================================================="
      #uri = URI('http://localhost:3001/users/new')                       #Octopus
      uri = URI('http://still-brushlands-80314.herokuapp.com/users/new')  #Octopus
      req = Net::HTTP::Post.new(uri, 'Content-Type' => 'application/json')
      req.body = {email: email, login: login, password: password, userType: userType, 
                  name1: name1, name2: name2, lastname1: lastname1, lastname2: lastname2, 
                  way: way, countryCode: countryCode, phoneNumber: phoneNumber, 
                  btcAddress: btcAddress}.to_json
      puts "\tWINDSHIELD : sending New user to  OCTOPUS\n\t#{req.body}"
      res = Net::HTTP.start(uri.hostname, uri.port) do |http|
        http.request(req)
      end
      resJson = JSON.parse res.body
      puts ("resJson: #{resJson}")
      puts ("resCode: #{res.code}")

      if res.code=='200' and resJson["status"]=='ok'
        render html: "<br><br><br><strong>Registrado exitosamente!</strong><p>Comenzara a recibir un SMS cuando tenga transacciones Bitcoin entrantes</p>".html_safe
        #render html: "<strong>Registrado exitosamente!</strong> <p>#{res.body}</p>".html_safe
        #render :json => { :status => :ok, :message => "Registrado exitosamente! #{res.body}"}
      else
        render html: "<strong>Verifique la informacion del formulario para el usuario</strong> <p>Error: #{res.body}</p>".html_safe
      end
    else
      render html: "<strong>Verifique la informacion del formulario para el usuario</strong> </p>".html_safe
      #format.json { render json: @user.errors, status: :unprocessable_entity }
    end
  end

  # PATCH/PUT /users/1
  # PATCH/PUT /users/1.json
  def update
    respond_to do |format|
      if @user.update(user_params)
        format.html { redirect_to @user, notice: 'User was successfully updated.' }
        format.json { render :show, status: :ok, location: @user }
      else
        format.html { render :edit }
        format.json { render json: @user.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /users/1
  # DELETE /users/1.json
  def destroy
    @user.destroy
    respond_to do |format|
      format.html { redirect_to users_url, notice: 'User was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_user
      @user = User.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def user_params
      params.fetch(:user, {})
    end
end
