class NotificationMethodsController < ApplicationController
  before_action :set_notification_method, only: [:show, :update, :destroy]

  # GET /notification_methods
  def index
    @notification_methods = NotificationMethod.all

    render json: @notification_methods
  end

  # GET /notification_methods/1
  def show
    render json: @notification_method
  end

  def findByAccount_id
    #puts Account.all.inspect
    ## aqui hay que contemplar el caso de que encuentre varios usuarios con igual address
    notificationmethod= NotificationMethod.find_by account_id: find_params[:account_id]
    render json: notificationmethod, status: :ok

  end

  # POST /notification_methods
  def create
    @notification_method = NotificationMethod.new(notification_method_params)
    if @notification_method.save
      render json: @notification_method.id, status: :created, location: @notification_method
    else
      render json: @notification_method.errors, status: :unprocessable_entity
    end
  end

  # PATCH/PUT /notification_methods/1
  def update
    if @notification_method.update(notification_method_params)
      render json: @notification_method
    else
      render json: @notification_method.errors, status: :unprocessable_entity
    end
  end

  # DELETE /notification_methods/1
  def destroy
    @notification_method.destroy
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    #this method saves the NotificationMethod into the instance variable @notification_method
    def set_notification_method 
      @notification_method = NotificationMethod.find(params[:id])
    end

    # Only allow a trusted parameter "white list" through.
    def notification_method_params
      params.require(:notification_method).permit(
        :way, :email, :countryCode, :phoneNumber, :telegramAlias, :account_id
      )
    end

    def find_params
      params.require(:notification_method).permit(:account_id)
    end
end
