class User < ApplicationRecord
	#falta validar que contenga arroba y un . al final y que sea unico
	validates :email, presence: true,
               length: { in: 5..40 }
    validates :login, length: {in: 3..24}
    validates :password, presence: true,
               length: { in: 8..50 }


    USERTYPE_OPTIONS = {'personal' => 'personal', 'company' => 'company'}
	validates_inclusion_of :userType, :in => USERTYPE_OPTIONS.values, :message => 'You must select personal or company type of user'
	has_many :account
end
