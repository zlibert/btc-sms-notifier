class NotificationMethod < ApplicationRecord
	belongs_to :account

	validates :countryCode, presence: true,
               length: { in: 2..4 }
    validates :phoneNumber, presence: true,
               length: { is: 10 }
end
