class Account < ApplicationRecord
	has_many :notificationmethod
	belongs_to :user
end
