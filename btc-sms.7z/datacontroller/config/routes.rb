Rails.application.routes.draw do
  resources :transactions
  resources :accounts
  resources :users
  resources :notification_methods
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html

	post '/accounts/find(.:format)', to: 'accounts#findByAddress'
	post '/transactions/find(.:format)', to: 'transactions#findByHash'
	post '/notification_methods/find(.:format)', to: 'notification_methods#findByAccount_id'
	post '/transactions/update(.:format)', to: 'transactions#updateByHash'
end
