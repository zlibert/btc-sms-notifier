# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema.define(version: 20170301235201) do

  # These are extensions that must be enabled in order to support this database
  enable_extension "plpgsql"

  create_table "accounts", force: :cascade do |t|
    t.string   "btcAddress"
    t.integer  "availableBalance"
    t.integer  "unconfirmedBalance"
    t.boolean  "managed"
    t.boolean  "VPOSmode"
    t.string   "defaultCurrency"
    t.datetime "created_at",         null: false
    t.datetime "updated_at",         null: false
    t.integer  "user_id"
    t.index ["user_id"], name: "index_accounts_on_user_id", using: :btree
  end

  create_table "notification_methods", force: :cascade do |t|
    t.string   "way"
    t.string   "email"
    t.string   "countryCode"
    t.string   "phoneNumber"
    t.string   "telegramAlias"
    t.datetime "created_at",    null: false
    t.datetime "updated_at",    null: false
    t.integer  "account_id"
    t.index ["account_id"], name: "index_notification_methods_on_account_id", using: :btree
  end

  create_table "transactions", force: :cascade do |t|
    t.string   "btcHash"
    t.float    "fiatAmount"
    t.string   "currency"
    t.integer  "btcAmount"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "users", force: :cascade do |t|
    t.string   "email"
    t.string   "login"
    t.string   "password"
    t.string   "userType"
    t.string   "name1"
    t.string   "name2"
    t.string   "lastname1"
    t.string   "lastname2"
    t.string   "profileDescription"
    t.string   "reputationScore"
    t.boolean  "verified"
    t.datetime "created_at",         null: false
    t.datetime "updated_at",         null: false
  end

  add_foreign_key "accounts", "users"
  add_foreign_key "notification_methods", "accounts"
end
