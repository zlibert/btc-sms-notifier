class CreateNotificationMethods < ActiveRecord::Migration[5.0]
  def change
    create_table :notification_methods do |t|
      t.string :way
      t.string :email
      t.string :countryCode
      t.integer :phoneNumber
      t.string :telegramAlias

      t.timestamps
    end
  end
end
