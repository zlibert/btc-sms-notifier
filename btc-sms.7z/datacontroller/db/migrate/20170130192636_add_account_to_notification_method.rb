class AddAccountToNotificationMethod < ActiveRecord::Migration[5.0]
  def change
    add_reference :notification_methods, :account, foreign_key: true
  end
end
