class CreateAccounts < ActiveRecord::Migration[5.0]
  def change
    create_table :accounts do |t|
      t.string :btcAddress
      t.integer :availableBalance
      t.integer :unconfirmedBalance
      t.boolean :managed
      t.boolean :VPOSmode
      t.string :defaultCurrency

      t.timestamps
    end
  end
end
