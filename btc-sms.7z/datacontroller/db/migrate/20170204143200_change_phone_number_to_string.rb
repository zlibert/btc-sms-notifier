class ChangePhoneNumberToString < ActiveRecord::Migration[5.0]
  def change
  	change_column :notification_methods, :phoneNumber, :string
  end
end
