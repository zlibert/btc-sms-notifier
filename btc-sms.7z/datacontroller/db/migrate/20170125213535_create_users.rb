class CreateUsers < ActiveRecord::Migration[5.0]
  def change
    create_table :users do |t|
      t.string :email
      t.string :login
      t.string :password
      t.string :userType
      t.string :name1
      t.string :name2
      t.string :lastname1
      t.string :lastname2
      t.string :profileDescription
      t.string :reputationScore
      t.string :int
      t.boolean :verified

      t.timestamps
    end
  end
end
