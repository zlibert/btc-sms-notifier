require 'test_helper'

class NotificationMethodTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
