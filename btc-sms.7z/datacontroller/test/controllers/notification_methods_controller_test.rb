require 'test_helper'

class NotificationMethodsControllerTest < ActionDispatch::IntegrationTest
  setup do
    @notification_method = notification_methods(:one)
  end

  test "should get index" do
    get notification_methods_url, as: :json
    assert_response :success
  end

  test "should create notification_method" do
    assert_difference('NotificationMethod.count') do
      post notification_methods_url, params: { notification_method: { countryCode: @notification_method.countryCode, email: @notification_method.email, phoneNumber: @notification_method.phoneNumber, telegramAlias: @notification_method.telegramAlias, type: @notification_method.type } }, as: :json
    end

    assert_response 201
  end

  test "should show notification_method" do
    get notification_method_url(@notification_method), as: :json
    assert_response :success
  end

  test "should update notification_method" do
    patch notification_method_url(@notification_method), params: { notification_method: { countryCode: @notification_method.countryCode, email: @notification_method.email, phoneNumber: @notification_method.phoneNumber, telegramAlias: @notification_method.telegramAlias, type: @notification_method.type } }, as: :json
    assert_response 200
  end

  test "should destroy notification_method" do
    assert_difference('NotificationMethod.count', -1) do
      delete notification_method_url(@notification_method), as: :json
    end

    assert_response 204
  end
end
