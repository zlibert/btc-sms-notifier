class TransactionsController < ApplicationController
 	skip_before_action :verify_authenticity_token, :only => [:create]

	def create
		date = btcTx_params[:received]
		btcHash = btcTx_params[:hash]
		#confirmations = btcTx_params[:confirmations]
		double_spend = btcTx_params[:double_spend]
		outputs = btcTx_params[:outputs]
		render :nothing => true, :status => 204 #evitar repeticion WebHook
		puts "\tHUBBLE : Event received. "
		outputs.each do |output|
			tempValue= output[:value]
			tempAddresses= output[:addresses]
			tempOutput= {incomingtransaction: {hash: btcHash, date: date, doubleSpend: double_spend,
				output: [value: tempValue, addresses: tempAddresses]}}
			## Aca estamos enviando uno por uno los outputs, en lugar de un arreglo
			## Esto se hizo para no demorar la entrega del demo, pero debe ser estudiada
			## la posibilidad y necesidad de que sea un arreglo JSON con todos los outputs juntos

			puts "\tSending Output JSON to OCTOPUS : \n\t#{tempOutput}"
			Thread.new do 	# A thread to SendSMS and avoid BlockCypher server to wait and assume
							# there was a connection problem and resend the POST
				#uri = URI('http://localhost:3001/incomingtransactions')        #octopus
				uri = URI('http://still-brushlands-80314.herokuapp.com/incomingtransactions')        	#octopus
	          	req = Net::HTTP::Post.new(uri, 'Content-Type' => 'application/json')
	          	req.body = tempOutput.to_json
	          	res = Net::HTTP.start(uri.hostname, uri.port) do |http|
	            	http.request(req)
	          	end#do
	          	puts "\tHUBBLE : Response from Octopus: \n\t#{res.body}"
          	end#Thread
          	#res= JSON.parse res.body    #save into hash
			#binding.pry
		end

	end

	private
		def btcTx_params
      params.require(:transaction).permit(
        :block_height, :block_index, :hash, 
        :total, :fees, :size, :preference, :relayed_by, :received, 
        :ver, :lock_time, :double_spend, :vin_sz, :vout_sz, :confirmations,
        :inputs => [ :prev_hash, :output_index, :script, :output_value, :sequence, :script_type, :addresses => [] ],
        :outputs => [ :value, :script, :script_type, :addresses => [] ],
        :addresses => [])
    	end
end

=begin
	------------------------------------------------------------------------------------------------------------
	if BlockCypher returns a tx-confidence factor of 99.99%, the probability of the transaction getting confirmed 
	by the block chain is almost certain. If we return a tx-confidence factor of 95%, the merchant can weigh whether 
	or not to process the transaction immediately or wait a few seconds more for the tx-confidence factor to go up 
	(within 10 seconds, BlockCypher typically returns a tx-confidence factor close to 99.9%).
=end
