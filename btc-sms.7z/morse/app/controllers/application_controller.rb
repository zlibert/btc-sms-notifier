class ApplicationController < ActionController::API
end#Class
