class SendmessagesController < ActionController::API		

## 				O J O
## INVESTIGAR SI ES FACTIBLE SMS SPOOFING EN VENEZUELA Y BUSCAR MANERA DE EVITARLO
## Una manera es revisar el centro de mensajes que envía el mensaje, debe pertenecer al país y ser el habitual
## SpoofTel cobra 0,5 USD por un SMS Spoof así que lógicamente la inversión para Spoofear a Deallar disuade de
## hacerlo para ciertos montos. Tambien requiere una tarjeta de credito que podria quedar logeado tu nombre ahi
## Se podrian garantizar montos de unos 4 dólares, dudo que por ahorrarse unos 3.5 dólares hagan eso
## Luego de eso se podria dejar a la suerte el cliente por notificacion SMS y se le sugiere no dar su tlf a nadie
## y se le manda una shared key intuitiva. Y se le sugiere que use email/telegram/whatsapp... o se arriesgue

## For international usage there must be a way to "switch" gateways according to phone number country code
## Something like def sendXXX (where XXX is country code number from 001 to 999)

	def create #+58 = Venezuela
		clientId = '172441988091507' # CentauroSMS Gateway Client ID
		uri = URI('http://post.centaurosms.com.ve')
		clientSecret = 'hSgKRfIHCRuQBaRnxQaa' #token-like key for my clientId
		
		if (message_params[:way] == 'sms')
			phoneNumber= message_params[:contact]
			if ( phoneNumberValid? (phoneNumber) and countryCodeValid? (message_params[:countryCode]) )
				# Encoding (centaurosms.com.ve required)
				contact= '{"id":"0","cel":"' + phoneNumber + '","nom":"test1"}'
				#essage= "Rcvd = %.2f" % fiatAmount + " VEF"
				url_encoded_string = CGI::escape(message_params[:message])
				#puts url_encoded_string
				encodedMsg= Base64.encode64(url_encoded_string)
				#puts message

				#   SEND SMS
				url_encoded_json = CGI::escape(contact)
				#puts url_encoded_json
				jsonContact= Base64.encode64(url_encoded_json)
				#puts jsonContact
				puts "============== CentauroSMS ================="
				response = Net::HTTP.post_form(uri, 'client_id' => clientId , 'client_secret' => clientSecret, 
					'client_opcion' => 'send_sms', 'json' => jsonContact, 'msg' => encodedMsg)
				puts response.body
				puts "============ endCentauroSMS ================"
				render :json => { :status => :ok, :message => "Message from Gateway: #{response.body}"}
			else
				render :json => { :status => :service_unavailable, :message => "ERROR SENDING MESSAGE - UNABLE TO SEND MESSAGE : #{response.body}"}
			end#if
		end#SMS

	end#create


	private
		def message_params
	    	params.permit(
		    	:way,			#email/sms
		        :contact,		# 4141234567 format | 3 to 14 numbers
		        :message,		#max lenght? 70 characters is max in some implementations
		        :name,			#optional: relate gateway names with user names? pros? cons?
		        :countryCode	# +XXX	|	1 to 3 numbers with a + prefix
	        )
    	end#message_params

    	#verificar que solo contenga numeros
    	def phoneNumberValid? (phoneNumber)
    		if (phoneNumber.length >=3 and phoneNumber.length <= 14)
    			return true
    		else
    			return false
    		end
    	end

    	def countryCodeValid? (code)
    		if (code.chars.first == '+' and code.length<=4 and code.length>=2)
    			return true
    		else
    			return false
    		end

    	end
end#Class
